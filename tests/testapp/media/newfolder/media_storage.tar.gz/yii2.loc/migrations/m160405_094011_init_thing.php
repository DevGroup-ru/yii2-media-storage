<?php

use yii\db\Migration;

class m160405_094011_init_thing extends Migration
{
    public function up()
    {
        $this->createTable('thing', [
            'id' => $this->primaryKey(),
            'prop' => $this->string(),
        ]);
    }

    public function down()
    {
        $this->dropTable('thing');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
