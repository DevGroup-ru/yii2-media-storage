<?php

namespace app\models;

use yii\db\ActiveRecord;
use app\modules\media\behaviors\RelationBehavior;

class Thing extends ActiveRecord
{
    public function behaviors()
    {
        return [
            'mediaRelation' => RelationBehavior::className(),
        ];
    }

    public static function tableName()
    {
        return 'thing';
    }
}
