#!/bin/bash
 
# Rebuild DB {
echo 'Recreate database ...'
mysql -u root -pmysql yii2 -e "DROP DATABASE yii2; CREATE DATABASE yii2; GRANT ALL PRIVILEGES ON yii2.* to 'yii2'@'localhost';"

echo 'Run migrations ...'
./yii migrate --interactive=0
./yii migrate --interactive=0 --migrationPath='vendor/yiisoft/yii2/rbac/migrations'
./yii migrate --interactive=0 --migrationPath='modules/media/migrations'

echo 'Creating initial data ...'
./yii init
# }

# Clean folders {
echo 'Clean folders ...'
rm -rf media-storage/
rm -rf runtime/media-storage/
# }
