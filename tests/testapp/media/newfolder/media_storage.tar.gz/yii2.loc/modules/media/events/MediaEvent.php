<?php

namespace app\modules\media\events;

use yii\base\Event;

class MediaEvent extends Event
{
    public $message;
}
