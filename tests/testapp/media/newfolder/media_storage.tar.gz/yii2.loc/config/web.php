<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log', 'media'],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'q-kI7AuTUP0rqGS3SHHlbI-CqD9x2m4d',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'authManager' => [
            'class' => 'yii\rbac\DbManager',
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                'media' => 'media/media/all-files',
                'media/groups' => 'media/media/all-groups',
                'media/show/item/<id:\d+>' => 'media/media/show-item',
                'media/show/group/<id:\d+>' => 'media/media/show-group',
                'media/save/item/<id:\d+>' => 'media/media/save-item',
                'media/save/group/<id:\d+>' => 'media/media/save-group',
                'media/delete/item/<id:\d+>' => 'media/media/delete-item',
                'media/delete/group/<id:\d+>' => 'media/media/delete-group',
                //'POST media/save/item<id:\d+>' => 'media/media/save-item',
                //'POST media/save/group<id:\d+>' => 'media/media/save-group',
                //'DELETE media/delete/item/<id:\d+>' => 'media/media/delete-item',
                //'DELETE media/delete/group/<id:\d+>' => 'media/media/delete-group',
            ],
        ],
        'fs' => [
            'class' => 'creocoder\flysystem\LocalFilesystem',
            'path'  => '@app',
        ],
    ],
    'modules' => [
        'media' => [
            'class' => 'app\modules\media\Module',
            'accessPermissions' => ['@'],
        ],
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];

    $config['components']['assetManager']['forceCopy'] = true;
}

return $config;
