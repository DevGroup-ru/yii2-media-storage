<?php

namespace app\commands;

use Yii;
use yii\console\Controller;
use yii\helpers\Json;
use app\modules\media\models\MediaGroup;
use app\modules\media\models\MediaPermission;

class InitController extends Controller
{
    public function actionIndex()
    {
        $auth = Yii::$app->authManager;

        Yii::$app->authManager->add($auth->createPermission('allow-edit-media-groups'));
        Yii::$app->authManager->add($auth->createPermission('random-item'));
        Yii::$app->authManager->add($auth->createRole('media-admin'));
        Yii::$app->authManager->add($auth->createRole('media-editor'));

        $group = new MediaGroup([
            'name' => 'Cats',
        ]);
        $group->save();
        $permission = new MediaPermission([
            'group_id' => $group->id,
            'name'     => 'media-admin',
        ]);
        $permission->save();

        $group = new MediaGroup([
            'name' => 'Books',
        ]);
        $group->save();
        $permission = new MediaPermission([
            'group_id' => $group->id,
            'name'     => 'random-item',
        ]);
        $permission->save();
    }
}
